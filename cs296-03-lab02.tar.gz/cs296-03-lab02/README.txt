group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

Sources:
(1) wikipedia page on make            : https://en.wikipedia.org/wiki/Make_%28software%29
(2) GNU Make Manual                   : https://www.gnu.org/software/make/manual/html_node/index.html#Top
(3) TLDP tutorial on making libraries : http://tldp.org/HOWTO/Program-Library-HOWTO/index.html
(4) tutorial on creating libraries    : http://www.yolinux.com/TUTORIALS/LibraryArchives-StaticAndDynamic.html
(5) several pages regardin make from  : http://stackoverflow.com/
