group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

Sources:
(1) The Advanced Bash Scripting Guide            : http://tldp.org/LDP/abs/html/
(2) An Introduction to Sed              			 	 : http://www.grymoire.com/Unix/Sed.html
(3) An Introduction to Awk							 : http://www.grymoire.com/Unix/Awk.html
(4) Stackoverflow													:http://www.stackoverflow.com
