#/bin/bash
taskid=$(pidof ./mybins/cs296_03_exe)
taskid=($taskid)
taskid=${taskid[0]}
if [ -z $taskid ]; then
	echo "Task not running."
else
myid=$(whoami)
user=$(ps -eo uname:50,pid,cmd | grep $taskid | grep ./mybins/cs296_03_exe | awk '{print $1}')
echo -n "The process id is : "
echo $taskid
echo -n "The user running the process is : "
echo $user
mygrep=$(ps -eo uname:50,pid,cmd | grep $taskid | grep $myid | grep ./mybins/cs296_03_exe)
if [ $? -eq 1 ]
then
    echo "You don't have the permission to kill this task."
else
	echo -n  "Do you want to kill the task cs296_03_exe? [y/n] "
	read myline
	if [ $myline = "y" ] || [ $myline = "Y" ] ;then
		kill $taskid
	fi
fi
fi

