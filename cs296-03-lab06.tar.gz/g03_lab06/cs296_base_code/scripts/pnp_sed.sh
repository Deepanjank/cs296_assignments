#!/bin/bash 
#Fitzwilliam is replaced by Anurag Shirolkar
#Darcy is replaced by Deepanjan Kundu
#Elizabeth is replaced by Syamantak Naskar


sed -e 's/``/"/g' \
	-e "s/''/\\\"/g" \
	-e 's/Fitzwilliam/Anurag Shirolkar/g' \
	-e 's/Darcy/Deepanjan Kundu/g' \
	-e 's/Elizabeth/Syamantak Naskar/g' <./data/pnp_austen.txt >./data/pnp_austen_cs296.txt
