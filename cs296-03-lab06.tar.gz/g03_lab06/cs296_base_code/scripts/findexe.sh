#!/bin/bash 
echo -n "Number of files: "
find $1 -type f | wc -l
echo -n "Number of directories :"
find $1 -type d | wc -l
exe=$(find $1 -type f -executable | wc -l)
if [ $exe = 0 ] ; then
	echo "No executable files in this directory."
else
echo "List of all executable files :"
find $1 -type f -executable
fi
