#!/bin/bash 
sort -k2 ~/.bash_history | uniq -c | sort -r -n | head -n 10
