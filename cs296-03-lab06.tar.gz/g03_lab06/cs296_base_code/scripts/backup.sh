#/bin/bash
path=$(df | grep media | tail -n  1 | awk '{print $6}')
cp -rf -u ./src/ $path/$1
