#!/bin/bash

ARG=$1
HOME=./
SRC=$HOME/src

if [ "$ARG" -eq 1 ]
then 
for i in $SRC/*.cpp
do
mv "$i" "$i.bak";
done
 
else [ "$ARG" -eq 2 ]
 ls $SRC/*.cpp | awk '{print "mv " $0}' | awk '{print $0 " "$NF".bak"}' | sh
fi
