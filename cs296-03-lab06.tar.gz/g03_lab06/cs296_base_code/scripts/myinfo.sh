#!/bin/bash
now=$(date)
G1=Deepanjan
G1_day=
G1_week=
G1_hour=
G2=Anurag 
G2_week=
G2_day=
G2_hour=
G3=Syamantak
G3_day=
G3_week=
G3_hour=
year=$(date  +%Y)
initial=($(who -b))
diff1=$(echo $(($(($(date -d "$year-07-09" +%s)-$(date +%s)))/3600))) 
diff2=$(echo $(($(($(date -d "$year-07-17" +%s)-$(date +%s)))/3600))) 
diff3=$(echo $(($(($(date -d "$year-02-05" +%s)-$(date +%s)))/3600))) 
diff4=$(echo $(($(date +%s)-$(date -d "${initial[2]} ${initial[3]}:00" +%s)))) 
if [ "$diff1" -lt 0  ]
then
diff1=$(($diff1+365*24))
fi
G1_week=$(($diff1/168))
G1_day=$(($(($diff1/24))%7))
G1_hour=$(($(($diff1%168))%24))
if [ "$diff2" -lt 0  ]
then
diff2=$(($diff2+365*24))
fi
G2_week=$(($diff2/168))
G2_day=$(($(($diff2/24))%7))
G2_hour=$(($(($diff2%168))%24))
if [ "$diff3" -lt 0  ]
then
diff3=$(($diff3+365*24))
fi
G3_week=$(($diff3/168))
G3_day=$(($(($diff3/24))%7))
G3_hour=$(($(($diff3%168))%24))
RUNNING=$( uptime| tr ',' ' ') 
arr=($RUNNING)
ubun=($( lsb_release -c))
ver=($( lsb_release -r))
ker=($( uname -r ))
disk=($(df 2>/dev/null))
ram=($(free -m))
word_count=$(wc -w <./scripts/myinfo.sh)
line_count=$(wc -l <./scripts/myinfo.sh)
char_count=$(cat ./scripts/myinfo.sh|tr -d " \n\r\f\t"|wc -c)
date +'Today is %A, %d %B, %Y.'
echo "There are $G1_week weeks $G1_day days and $G1_hour hours left for the birthday of $G1"
echo "There are $G2_week weeks $G2_day days and $G2_hour hours left for the birthday of $G2"
echo "There are $G3_week weeks $G3_day days and $G3_hour hours left for the birthday of $G3" 
echo "Thank you for asking, $(logname)"
echo "Your system has been running for $(($diff4/86400)) days, $(($((diff4%86400))/3600)):$(($(($((diff4%86400))%3600))/60)) hours."
echo "The current disk on which your home folder is located is ${disk[7]} and is ${disk[11]} full"
echo "You are running ${ubun[1]} and ${ver[1]} with Kernel ${ker[0]}"
echo "Your machine has $(echo "scale=5; ${ram[7]}/1024" | bc) GB RAM.Of which $(echo "scale=5; ${ram[8]}*100/${ram[7]}" | bc)% is in use" 
echo "This script has $word_count words, $line_count lines and $char_count characters (without counting whitespace)"
