#!/bin/bash
ARG=$1
HOME=./
SRC=$HOME/src
if [ "$ARG" -eq 1 ]
then
tar -czf src.tar.gz src

elif [ "$ARG" -eq 2 ]
then 
gzip -q  $SRC/*;
tar -cf src.tar src;
gzip -d $SRC/*;
fi
