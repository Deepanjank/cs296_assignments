group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

Sources:
(1) wikipedia pages involving physics            : https://en.wikipedia.org/
(2) Latex forum                 			 	 : tex.stackexchange.com
(3) DOxygentutorials							 : http://www.stack.nl/~dimitri/doxygen/manual/index.html
(4) Resnick,Halliday    						 : ebook
(5) box2Dtutorials								 : http://www.box2D.org/manual/index.html
(6) box2Dforum									 : http://www.iforce2d.net/b2dtut/
(7) Latex tutorial								 : http://www.andy-roberts.net/writing/latex
