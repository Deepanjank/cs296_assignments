group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

RELATIONSHIP BETWEEN CLASSES:
JMessage       : contains message string
JPacket        : contains JMessage and timestamp String
JChatSession   : contains log of all JPackets exchanged
JChatComm      : contains object of JChatSession and socket
JClient        : Inherited from JChatComm, contains method callServer
JServer        : Inherited from JChatComm, contains method acceptConnection

When a server gets a request from client it asks the user if he wants to chat with the client.
If user enters "y" then the chat begins otherwise the connection of the client is timed out.
Date and time is shown only for the received messages. This way we can differetiate between the
sent messages and received messages.


Sources:
Thinking in Java: http://www.mindviewinc.com/Books/TIJ/
Stack Overflow :    www.stackoverflow.com
Java SE 6 Documentation : http://docs.oracle.com/javase/6/docs/api/
Java Tutorials : http://docs.oracle.com/javase/tutorial/
