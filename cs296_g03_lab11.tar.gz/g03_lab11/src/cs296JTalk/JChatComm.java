package cs296JTalk;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
public class JChatComm {
	boolean myClose=true;
	public int port=5123;
	public JChatSession session=new JChatSession();
	public Socket socket;
	public String identity;
	public JChatComm(String cs) 
	{
		identity=cs;
	}
	
	public void sendMessage()
	{
		try{
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			String s=br.readLine();
			JMessage m=new JMessage(s);
		JPacket temp=new JPacket(m,getCurrentTimeStamp());
		ObjectOutputStream output= new ObjectOutputStream(socket.getOutputStream());
        output.writeObject(temp);
        output.flush();
        printLog(temp,identity);
        if(temp.message.message.equals("End Chat"))
        {
        	myClose=false;
        	session.printLog();
        }
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
		


	public void receiveMessage(){
		try{
			ObjectInputStream input= new ObjectInputStream(socket.getInputStream());
	        JPacket temp=(JPacket)input.readObject();
	        System.out.println("\n"+temp.message.message+"\t( "+temp.timeStamp+" )\n");
	        printLog(temp,inverseIdentity());
	        if(temp.message.message.equals("End Chat"))
	        {
	        	endChat();
	        	myClose=false;
	        }
			}
			catch(Exception e)
			{
				System.out.println("Chat Ended");
				myClose=false;
			}
	}
	
	public String inverseIdentity()
	{
		if (identity.equals("Server"))
		{
			return "Client";
		}
		else 
			return "Server";
	}



//method printLog - to print out the chat




public void printLog(JPacket temp,String identity)
{
	session.addToMyList(temp,identity);
}

public void endChat()
{
	try {
		socket.close();
		session.printLog();
	} catch (IOException e) {
		e.printStackTrace();
	}
}

public String getCurrentTimeStamp(){ 
	Date date = new Date();
	SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy h:mm:ss a");
	String formattedDate = sdf.format(date);
	return formattedDate;
}
}
