package cs296JTalk;
import java.io.Serializable;

public class JMessage implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
public String message;
public JMessage()
{
	message="";
	}
public JMessage(String s)
{
if(s.length()<=140)
{
message=s;	
}
else 
	message=s.substring(0, 140);
}
}
