package cs296JTalk;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;

public class JServer extends JChatComm{
	public JServer() 
	{
		super("Server");

	}
	public void acceptConnection(){
		try{

			ServerSocket s=new ServerSocket(port);
			System.out.println("Waiting on port " + port);

			while(true)
			{
				socket = s.accept();
				ObjectOutputStream output= new ObjectOutputStream(socket.getOutputStream());
				ObjectInputStream input= new ObjectInputStream(socket.getInputStream());
				JPacket temp= (JPacket)input.readObject();
				printLog(temp,"Client");
				if((temp.message.message).equals("Free for a chat?"))
				{
					System.out.print("Client:Free for a chat?\n"+"Enter y if you wanna chat (to send Sure. Let us begin.) with "+ socket.getInetAddress()+":-");
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					String my=br.readLine();
					if(my.equals("y")){

						output.writeObject(new JPacket(new JMessage("Sure. Let us begin."),getCurrentTimeStamp()));
						output.flush();
						printLog(temp,"Server");
						break;		
					}
					
				}
				//do it

			}
		}
		catch(Exception e){
			System.out.println("Client No Longer there");
			session.printLog();
		}
	}
}
