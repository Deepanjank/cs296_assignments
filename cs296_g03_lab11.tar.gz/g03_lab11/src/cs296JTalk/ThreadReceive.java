package cs296JTalk;

import java.io.IOException;

public class ThreadReceive extends Thread{

	public JChatComm com;
	public ThreadReceive (JChatComm a)
	{
		com=a;
	}
	public void run() 
	{
		//System.out.println(12);
		while(com.myClose)
		{
			//System.out.println(1241);
			com.receiveMessage();
		}
	}
}
