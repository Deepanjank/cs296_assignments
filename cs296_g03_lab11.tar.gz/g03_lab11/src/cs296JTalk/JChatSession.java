package cs296JTalk;

import java.util.ArrayList;
import java.util.List;

public class JChatSession {
public class MessageTags
{
private JMessage message;
private String sender;
private String TimeStamp;

	public MessageTags(JPacket p,String s)
	{
		message=p.message;
		sender=s;
		TimeStamp=p.timeStamp;
	}
}
public List<MessageTags> myList=new ArrayList<JChatSession.MessageTags>();
public JChatSession()
{}
public void printLog()
{
	System.out.println("\t\t\tMY lOGS:");
for (MessageTags i:myList)
{
System.out.println("Time :- "+i.TimeStamp+"\n"+i.sender+" :- "+i.message.message);	
}
}
public void addToMyList(JPacket p,String s)
{
	MessageTags myTag=new MessageTags(p,s);
	myList.add(myTag);
}
}
