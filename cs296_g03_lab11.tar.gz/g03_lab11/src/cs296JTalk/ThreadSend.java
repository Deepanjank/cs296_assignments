package cs296JTalk;

import java.io.IOException;

public class ThreadSend extends Thread{

	public JChatComm com;
	public ThreadSend (JChatComm a)
	{
		com=a;
	}
	public void run() 
	{
		while(com.myClose)
		{
			try {
				if(System.in.available()!=0)
				//System.out.println(1241);
					com.sendMessage();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
	}
}
