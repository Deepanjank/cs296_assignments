package cs296JTalk;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

public class JClient extends JChatComm{
	public int port=5123 ;
	public String IP;
	public boolean isReady;
	public JClient() 
	{
		super("Client");
		isReady=false;
	}
	public void callServer(String ipAddress) 	{
		try{
			socket=new Socket(ipAddress, port);
			socket.setSoTimeout(10000);

			ObjectOutputStream output= new ObjectOutputStream(socket.getOutputStream());
			JMessage m=new JMessage("Free for a chat?");
			JPacket temp=new JPacket(m,getCurrentTimeStamp());
			output.writeObject(temp);
			output.flush();
			printLog(temp,"Client");
			ObjectInputStream input= new ObjectInputStream(socket.getInputStream());
			temp=(JPacket)input.readObject();
			printLog(temp,"Server");
			socket.setSoTimeout(0);
			System.out.println("d");
			if(! temp.message.message.equals("Sure. Let us begin."))
			{
				System.out.println("Protocol is wrong");
				socket.close();
			}
			else{
				System.out.println("Server:-"+"Sure. Let us begin.");
				isReady=true;
			}

			//add a initiator

		}
		catch(SocketTimeoutException e){
			System.out.println("Connection timed out");
		} 
		catch (UnknownHostException e) {

			e.printStackTrace();
		} 
		catch (IOException e) {
			System.out.println("Server not there");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
