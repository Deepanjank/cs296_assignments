package cs296JTalk;

import java.io.Serializable;

public class JPacket implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
JMessage message;
String timeStamp;
JPacket(JMessage m,String tStamp)
{
message=m;
timeStamp=tStamp;;	
}	
}
