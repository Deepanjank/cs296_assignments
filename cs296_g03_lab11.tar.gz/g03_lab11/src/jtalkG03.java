import cs296JTalk.JChatSession;
import cs296JTalk.JClient;
import cs296JTalk.JServer;
import cs296JTalk.ThreadReceive;
import cs296JTalk.ThreadSend;
public class jtalkG03 {
	public static void main(String [ ] args)
	{
		JChatSession session;
		if(args.length!=0){
		JClient myClient=new JClient();
		myClient.callServer(args[0]);
		session=myClient.session;
		//System.out.println(myClient.isReady);
		if(myClient.isReady)
		{
			Thread sender=new ThreadSend(myClient);
			sender.start();

			Thread receiver=new ThreadReceive(myClient);
			receiver.start();
		
		}
		
		
		}
		else 
		{
			
			JServer myServer=new JServer();
			session=myServer.session;
			myServer.acceptConnection();
		
			Thread sender=new ThreadSend(myServer);
			sender.start();

			Thread receiver=new ThreadReceive(myServer);
			receiver.start();

	}
		
}
}
