Lab 04
group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

Sources:
(1) The Advanced Bash Scripting Guide           : http://tldp.org/LDP/abs/html/
(2) Gnuplot homepage                			 	 : http://www.gnuplot.info/
(3) Gnuplot Demos						 : http://gnuplot.sourceforge.net/demo/index.html
(4) An Introduction to Sed   						 : http://www.grymoire.com/Unix/Sed.html
(5) An Introduction to Awk								 : http://www.grymoire.com/Unix/Awk.html

