group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.



ALGORITHM DESCRIPTION:
g03_script_info.py:
The script prints the first line as title and assumes that the next line is by or written by and then 
follows the authors name.

g03_moviechars.py
The names of characters are given over their dialogues in uppercases. The algorithm first finds all the phrases which are in uppercases and consist of less than five words. Then it filters them through a list of frequently used english words like day, morning, evening, etc. We also consider the words with prefixes like Mr., Dr. etc. To count the occurrences of the characters we go through the script and count the occurrence of that particular name if the count is too low then we exclude them.
 
g03_movieactors.py:
The gender determination sees two things.The occurence of certain keywords in the vicinity of a character name 
whereever it appears in the movie script.There are seperate male and female words.We consider the ratio  of such numbers with 
total occurence of such words in the script and compare them for the female and male with in certain errors.Else the characters 
have an undetermined.Also the characters occuring less frequently have also been given undetermined gender because they have lot of ambiguity attached with them.Plus if a character name has words like female,woman,wife etc. then they have been given the required gender.

We have assumed that the most frequent male character to be the hero of the movie, most frequent female character to be heroine. To find the villain we provide more weightage to the names that occure more at the end of the movie. If the most frequent names are close to each othere in frequency then we have considered both of them to be heores.

g03_movietype.py:
For each genre we consider a particular set of keywords and count the occurrences of them in the entire script. The genres which have more frequency than a particular limit are included.


Sources:
Python3 Tutorial:  http://docs.python.org/3/tutorial/
Learning with Python 3:  http://www.openbookproject.net/thinkcs/python/english3e/
Stack Overflow :    www.stackoverflow.com
learn python the hard way:   http://learnpythonthehardway.org/book/
