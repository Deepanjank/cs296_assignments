import sys
import operator






prep = ['today', 'yesterday', 'tomorrow', 'home', 'bridge', 'road', 'highway', 'kitchen', 'bathroom', 'monday', 'sunday', 'tuesday', 'wednesday', 'tursday', 'friday', 'saturday', 'at', 'the', 'on', 'in', 'under', 'of', 'later', 'after', 'before', 'voice', 'night', 'morning', 'day', 'afternoon']




def findoccurrences(s, sub):
	l = len(s)
	count = 0
	for i in range(len(sub) - l + 1):
		cur = 0
		while cur < l:
			if not s[cur] in sub[i+cur]:
				break
			if cur == l-1:
				count += 1
			cur += 1
	return count


def checkupper(a):
	ans = True
	for i in a:
		ans = ans and (ord(i) < 97 or ord(i) > 122)
	return ans
def checkname(a):
	if a in prep:
		return False
	ans = True
	for i in a.split():
		ans = ans and len(i)>1
	for i in a :
		ans = ans and not( i in [':', ';', '-', '_', '.', '!', '?', '(', ')', ',', '#' ])
	return ans

name=input("Please input file name:")
filename = name
f = open(filename)
lines=f.readlines()

for i in range(len(lines)):
	lines[i] = lines[i].strip()
words = []
words.extend(lines)
for i in range(1,len(lines)):
	words[i] = lines[i].split()

chars = []

for i in range(len(words)):
	if len(words[i]) < 5:
		all_upper = True
		if lines[i].isupper() and checkname(lines[i]) and not(lines[i] in chars) :
			chars.append(lines[i])


#purifying
chars_l = []
for i in chars:
	chars_l.append(i.lower())

words_l = []
me=[]
for i in words:
	temp = []
	for j in i:
		temp.append(j.lower())
		me.append(j.lower())
	words_l.append(temp)




#finding Dr. Mr. Mrs.

tags=['dr.', 'mr.', 'mrs.', 'ms.']

for i in words_l:
	for  j in range(len(i)):
		if i[j] in tags and j != len(i)-1:
			occurs = False
			for k in chars_l:
				if i[j+1] in k:
					occurs = True
					break
			if not(occurs) and checkname(i[j+1]):
				chars_l.append(i[j+1])




#counting
count = {}
for i in chars_l:
	count[i] = 0
for i in lines:
	for j in chars_l:
		if j in i.lower():
			count[j]= count[j] + 1

charlen = len(chars_l)
i = 0
while i < charlen:
	temp = [filter(lambda x: x in prep, sublist) for sublist in chars_l[i].split()]
	if temp != [] and count[chars_l[i]] < 4:
		count.pop(chars_l[i])
		chars_l.pop(i)
		i = i - 1
		charlen -= 1
	i = i + 1

count = {}

chars_split=[]
for i in chars_l:
	chars_split.append(i.split())
for i in chars_l:
	count[i] = 0

for i in words_l:
	for j in range(len(chars_split)):
		count[chars_l[j]] += findoccurrences(chars_split[j], i)
		



charlen = len(chars_l)
i1 = 0 
while i1 < charlen:
	i = chars_l[i1] 
	if count[i] < 0 or i == 'the end' or i in prep: 
		count.pop(i)
		chars_l.pop(i1) 
		i1 = i1 - 1 
		charlen -= 1 
	i1 = i1 + 1


key_words_m=['he','his','him','man','father','brother','dude']
key_words_f=['she','her','girl','lady','wife','mother','sister','daughter','mom']
keym=0
keyf=0
totm=0
totf=0
key=[0,0,0,0,0,0,0,0,0] #he,she,his,her,boy,guy,man,girl,woman
for k in me:
        if k in key_words_m:
                totm=totm+1
        elif k in key_words_f:
                totf=totf+1

gender=['Undetermined']*len(chars_l)

for i in range(len(chars_l)):
	if gender[i]=='Undetermined':
		for j in range(len(words_l)-2):
			if chars_l[i] in words_l[j]:
				for x in words_l[j]:
					if x in key_words_m:
						keym=keym+1;
					elif x in key_words_f:
						keyf=keyf+1;
			for x in words_l[j+1]:
                                        if x in key_words_m:
                                                keym=keym+0.5;
                                        elif x in key_words_f:
                                                keyf=keyf+0.5;
			for x in words_l[j+2]:
                                        if x in key_words_m:
                                                keym=keym+0.25;
                                        elif x in key_words_f:
                                                keyf=keyf+0.25;
		pre=0
		temp=0
		for j in me:
                        if pre=='mr.' and j in chars_l[i]:
                                gender[i]='Male'
                                keym=10000
                                break
                        elif (pre=="mrs." or pre=="miss") and j in chars_l[i] :
                                gender[i]='Female'
                                keyf=10000
                                break
                        elif j in key_words_m and temp>=1:
                                keym+=temp*0.1
                                temp=0
                        elif j in key_words_f and temp>=1:
                                keyf+=temp*0.1
                                temp=0
                        elif j in chars_l[i]:
                                temp+=1
                        pre=j
	
		
		if(count[chars_l[i]]<15):
			gender[i]='Undetermined'
		elif (keyf*totm>keym*totf):
			gender[i]='Female'
		elif (keyf*totm<keym*totf):
			gender[i]='Male'	
		else :
			gender[i]='undetermined'
		for k in ['son','dad','father','boy','man','boyfriend','husband']:
			if k in chars_l[i]:
				gender[i]='Male'
				break
		for k in ['daughter','girl','sister','sis','mom','wife','girlfriend', 'woman', 'women']:
			if k in chars_l[i]:
				gender[i]='Female'
				break
		keyf=0
		keym=0

temp_gender = []
for i in range(len(chars_l)):
	temp = [chars_l[i], count[chars_l[i]], gender[i]]
	temp_gender.append(temp)
temp_gender.sort(key=operator.itemgetter(0))


for i in temp_gender:
	print(i[0].upper() , "    ", i[1], "     ", i[2])
















all_data = []
for i in range(len(chars_l)):
	temp = [chars_l[i], count[chars_l[i]], gender[i]]
	all_data.append(temp)
all_data.sort(key=operator.itemgetter(1))
all_data = all_data[::-1]
male_cand=[]
female_cand=[]

for i in all_data:
	if i[2] == 'Male':
		if len(male_cand) < 6:
			male_cand.append(i[0])
	if i[2] == 'Female':
		if len(female_cand) < 6:
			female_cand.append(i[0])

count_male={}
count_female={}
for i in male_cand:
	count_male[i] = [0,0,0,0,0,0]
for i in female_cand:
	count_female[i] = [0,0,0,0,0,0]

cur = -1

for i1 in range(len(words_l)):
	i = words_l[i1]
	if i1 % (len(words_l)//5) == 0:
		cur += 1
	for j in male_cand:
		count_male[j][cur] += findoccurrences(j.split(), i)
	for j in female_cand:
		count_female[j][cur] += findoccurrences(j.split(), i)



wt_male={}
wt_female={}
ratio =[1,2,3,4,5]

for i in male_cand:
	wt_male[i]= 0
	for j in range(5):
		wt_male[i] += ratio[j]*count_male[i][j]
	wt_male[i] = wt_male[i]/(sum(count_male[i]))
	if count[i] < all_data[0][1]/10:
		wt_male[i] = 0

sorted_wt= []
for i in wt_male:
	temp = [i, wt_male[i]]
	sorted_wt.append(temp)

sorted_wt.sort(key=operator.itemgetter(1))
sorted_wt = sorted_wt[::-1]
villain = sorted_wt[0][0]
if male_cand[0] == sorted_wt[0][0] :
	villain = sorted_wt[1][0]
heroes=[male_cand[0]]
if(count[male_cand[0]] - count[male_cand[1]] < count[male_cand[0]]/10 and male_cand[1] != villain):
	heroes=[male_cand[0], male_cand[1]]

print('\n\n\n\n')
if len(heroes) == 1:
	print("The Hero is:     ",male_cand[0])
else :
	print("The Heroes are:  ",male_cand[0], " and ", male_cand[1])
print("The Villain is:  ",villain)
print("The Heroin is:   ",female_cand[0])
