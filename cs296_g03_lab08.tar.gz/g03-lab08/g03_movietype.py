act = ['crime', 'spy', 'kill', 'pilot', 'hurt', 'end', 'fast', 'run', 'crew', 'shoot', 'kick', 'weapon', 'tank', 'fir', 'bullet', 'explo', 'toss',  'train', 'karate', 'kung-fu']
tot_act= 0

com = ['cool', 'married', 'sex', 'fun', 'beer', 'crash', 'dude', 'idiot', 'shit', 'parody', 'happy', 'happi', 'smile', 'confused', 'shout', 'honey', 'giggle', 'laugh', 'dance', 'joy', 'ha ha']
tot_com= 0

dra = ['daddy', 'colonel', 'husband', 'state', 'sick', 'sense', 'pool' 'returns', 'emotion', 'cry', 'cri', 'hope', 'judge', 'jury', 'king', 'queen']
tot_dra= 0

rom = ['love', 'cuddle', 'married', 'sailor', 'crash', 'shepherd', 'wills', 'daughter', 'letter', 'surprised', 'restaurant', 'wedding', 'met', 'funny', 'fun']
tot_rom= 0

sci = ['alien', 'planet', 'galaxy' , 'universe ', 'monitor', 'crew', 'robot', 'duke', 'console', 'pilot', 'spider', 'level', 'system', 'tank', 'panel', 'weapon', 'skin', 'hunter', 'brain', 'astro', 'comput', 'law', 'nano', 'space', 'star']
tot_sci= 0

hor = ['cabin', 'skin', 'bones', 'vampire', 'teeth', 'jeep', 'woods', 'hunter', 'scared', 'bloody', 'death', 'psycopath', 'evil', 'murder', 'zombie', 'monster', 'devil', 'demon', 'ghost']
tot_hor= 0

fan = ['lord', 'dragon', 'unicorn', 'wizard', 'witch', 'knight', 'furious', 'doom', 'queen', 'final', 'cat', 'curse', 'dragons', 'merry', 'wizard', 'prince', 'hobbit', 'elves', 'dragon', 'monster']
tot_fan= 0



filename = input("Please enter the filepath: ")
f=open(filename)
lines=f.readlines()

for i in range(len(lines)):
		lines[i] = lines[i].strip().lower()


for i in range(len(lines)):
	if any(word in lines[i] for word in act):		
		tot_act += 1
	if any(word in lines[i] for word in com):		
		tot_com += 1
	if any(word in lines[i] for word in dra):		
		tot_dra += 1
	if any(word in lines[i] for word in rom):		
		tot_rom += 1
	if any(word in lines[i] for word in hor):		
		tot_hor += 1
	if any(word in lines[i] for word in fan):		
		tot_fan += 1
	if any(word in lines[i] for word in sci):		
		tot_sci += 1	

sum = tot_act + tot_com + tot_dra + tot_rom + tot_hor + tot_fan + tot_sci

#genre = [tot_act/sum, tot_com/sum, tot_dra/sum, tot_rom/sum, tot_hor/sum, tot_fan/sum, tot_sci/sum ]
#genre.sort(reverse=True)

print("Genre :")

if tot_act/sum > 0.15 or tot_act>=100:		
	print ("Action")

if tot_com/sum > 0.15 or tot_com>=100:		
	print ("Comedy")

if tot_dra/sum > 0.15 or tot_com>=120:		
	print ("Drama")

if tot_rom/sum > 0.15 or tot_rom>=120:		
	print ("Romance")

if tot_hor/sum > 0.15 or tot_hor>=80:		
	print ("Horror")

if tot_fan/sum > 0.15 or tot_fan>=100:		
	print ("Fantasy")

if tot_sci/sum > 0.15:		
	print ("Sci-Fi")
