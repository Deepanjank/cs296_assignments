import sys
import operator


prep = ['today', 'yesterday', 'tomorrow', 'home', 'bridge', 'road', 'highway', 'kitchen', 'bathroom', 'monday', 'sunday', 'tuesday', 'wednesday', 'tursday', 'friday', 'saturday', 'at', 'the', 'on', 'in', 'under', 'of', 'later', 'after', 'before', 'morning', 'night', 'afternoon', 'evening']

def findoccurrences(s, sub):
	l = len(s)
	count = 0
	for i in range(len(sub) - l + 1):
		cur = 0
		while cur < l:
			if not s[cur] in sub[i+cur]:
				break
			if cur == l-1:
				count += 1
			cur += 1
	return count


def checkupper(a):
	ans = True

	for i in a:
		ans = ans and (ord(i) < 97 or ord(i) > 122)
	return ans

def checkname(a):
	ans = True
	if a in prep:
		return False
	for i in a.split():
		ans = ans and len(i)>1
	for i in a :
		ans = ans and not( i in [':', ';', '-', '_', '.', '!', '?', '(', ')', ',', '#' ])
	return ans

name=input("Please input file name:")
filename = name
f = open(filename)
lines=f.readlines()

for i in range(len(lines)):
	lines[i] = lines[i].strip()
words = []
words.extend(lines)
for i in range(1,len(lines)):
	words[i] = lines[i].split()

chars = []

for i in range(len(words)):
	if len(words[i]) < 5:
		all_upper = True
		if lines[i].isupper() and checkname(lines[i]) and not(lines[i] in chars) :
			chars.append(lines[i])


#purifying
chars_l = []
for i in chars:
	chars_l.append(i.lower())

words_l = []
for i in words:
	temp = []
	for j in i:
		temp.append(j.lower())
	words_l.append(temp)




#finding Dr. Mr. Mrs.

tags=['dr.', 'mr.', 'mrs.', 'ms.']

for i in words_l:
	for  j in range(len(i)):
		if i[j] in tags and j != len(i)-1:
			occurs = False
			for k in chars_l:
				if i[j+1] in k:
					occurs = True
					break
			if not(occurs) and checkname(i[j+1]):
				chars_l.append(i[j+1])




#counting
count = {}
for i in chars_l:
	count[i] = 0
for i in lines:
	for j in chars_l:
		if j in i.lower():
			count[j]= count[j] + 1

prep = ['today', 'yesterday', 'tomorrow', 'home', 'bridge', 'road', 'highway', 'kitchen', 'bathroom', 'monday', 'sunday', 'tuesday', 'wednesday', 'tursday', 'friday', 'saturday', 'at', 'the', 'on', 'in', 'under', 'of', 'later', 'after', 'before']


charlen = len(chars_l)
i = 0
while i < charlen:
	temp = [filter(lambda x: x in prep, sublist) for sublist in chars_l[i].split()]
	if temp != [] and count[chars_l[i]] < 4:
		count.pop(chars_l[i])
		chars_l.pop(i)
		i = i - 1
		charlen -= 1
	i = i + 1

count = {}

chars_split=[]
for i in chars_l:
	chars_split.append(i.split())
for i in chars_l:
	count[i] = 0

for i in words_l:
	for j in range(len(chars_split)):
		count[chars_l[j]] += findoccurrences(chars_split[j], i)
	



charlen = len(chars_l)
i1 = 0
while i1 < charlen:
	i = chars_l[i1]
	if count[i] < 0 or i == 'the end' or not(checkname(i)):
		count.pop(chars_l[i1])
		chars_l.pop(i1)
		i1 = i1 - 1
		charlen -= 1
	i1 = i1 + 1

temp_count=[]
for i in count:
	temp_count.append([i, count[i]])

temp_count.sort(key=operator.itemgetter(0))
for i in temp_count:
	print(i[0].upper() , "     " , i[1])
