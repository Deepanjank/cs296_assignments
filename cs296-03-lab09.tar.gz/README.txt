group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.


Sources:
Matplotlib : http://matplotlib.org/
Numpy : http://www.numpy.org/
Python3 Tutorial:  http://docs.python.org/3/tutorial/
Learning with Python 3:  http://www.openbookproject.net/thinkcs/python/english3e/
Stack Overflow :    www.stackoverflow.com
learn python the hard way:   http://learnpythonthehardway.org/book/
