package cs296MovieAnalysis;

import java.io.*;
import java.util.*;

import cs296MovieAnalysis.MovieStatistics.Character;


public class FindActors extends MovieStatistics{
    //look at the use of inheritance
	/**\par
	 * variable names: ratios <br>
	 * the map of number of occurrences of characters in 5 regular intervals
	 */
	private Map<String, Integer[]> ratios;
	
	/**\par
	 * variable names: EvilWt <br>
	 * the map of evilWt of each character
	 */
	private Map<String, Double> evilWt;
	
	/**\par
	 * variable names: hero <br>
	 * name of the hero
	 */
	private String hero;
	
	/**\par
	 * variable names: heroine <br>
	 * name of the heroine
	 */
	private String heroine;
	
	/**\par
	 * variable names: villain <br>
	 * name of the villain
	 */
	private String villain;

	
	/**\par
	 * constructor <br>
	 * finds ratios, evilWts, hero, heroine, villain and stores them in corresponding variables
	 */
	public FindActors(Movie movie){
		super(movie);
		getsort();
		ratios = new HashMap<String, Integer[]>();
		evilWt = new HashMap<String, Double>();
		getRatios();
		getEvilWt();
		hero = findHero();
		heroine = findHeroine();
		villain = findVillain();
	}
	
	/**\par
	 * method name: getRatios <br>
	 * finds the number of occurrences of characters in 5 regular intervals and stores them in the map ratios
	 */
	private void getRatios(){
		int noSteps = 5;
		int step = statsMovie.lines.size()/noSteps+1;
		for(Character c : characters) ratios.put(c.name, new Integer[]{0,0,0,0,0});
		for(Character chr : characters){
			String c = chr.name;
			String[] charSplit = c.split(" ");
			int cur = -1;
			for (int i = 0; i < statsMovie.wordsLower.size(); i++) {
				if(i%step == 0) cur++;
				int temp = findOccurrences(charSplit, statsMovie.wordsLower.get(i));
				if(temp>0){
					Integer[] t = ratios.get(c);
					t[cur]+=temp;
					ratios.put(c,t);
				}
			}
		}
	}

	/**\par
	 * method name: getEvilWt <br>
	 * finds the evilWt of each character and stores it in map evilWt
	 */
	private void getEvilWt(){
		int maxOcc = 0;
		for(Character c : characters) if(c.count > maxOcc) maxOcc = c.count;
		int noSteps = 5;
		for(Character c : characters){
			if(c.count < maxOcc/10) evilWt.put(c.name, 0.0);
			else {
				Double wt = 0.0;
				for (int i = 0; i < noSteps; i++) {
					wt += (i+1)*ratios.get(c.name)[i];
				}
				wt /= c.count;
				evilWt.put(c.name, wt);
			}
		}
	}
	
	private Character[] getsort(){
		Arrays.sort(characters);
		return characters;
	}

	/**\par
	 * method name: findHero <br>
	 * returns the name of the hero <br>
	 * implemented sorting function using interface
	 */
	private String findHero(){
		/*int maxOcc = 0;
		String maxName = "No Male Character";
		for(Character c : characters){
			if(c.count > maxOcc && c.gender.equals("male")){
				maxOcc = c.count;
				maxName = c.name;
			}
		}
		return maxName;*/
		for(Character c : characters){
			if(c.gender.equals("male")){
				return c.name;
			}
		}
		return "";
	}

	/**\par
	 * method name: findHeroine <br>
	 * returns the name of the heroine
	 */
	private String findHeroine(){
		int maxOcc = 0;
		String maxName = "No Female Character";
		for(Character c : characters){
			if(c.count > maxOcc && c.gender.equals("female")){
				maxOcc = c.count;
				maxName = c.name;
			}
		}
		return maxName;
	}

	/**\par
	 * method name: findVillain <br>
	 * returns the name of the villain
	 */
	private String findVillain(){
		double maxEvil = -1.0;
		String maxName = "";
		for(Character c : characters){
			if(evilWt.get(c.name) > maxEvil && !c.name.equals(hero) && !c.name.equals(heroine)){
				maxEvil = evilWt.get(c.name);
				maxName = c.name;
			}
		}
		return maxName;
	}
	
	/**\par
	 * method name: printActors <br>
	 * prints the name of the hero, heroine and villain
	 */
	public void printActors(){
		System.out.println("\nTHE MOVIE HAS FOLLOWING MAIN CHARACTERS: ");
		System.out.println("The name of the hero is : "+ hero.toUpperCase());
		System.out.println("The name of the heroine is : "+ heroine.toUpperCase());
		System.out.println("The name of the villain is : "+ villain.toUpperCase());
		
	}
	
}