package cs296MovieAnalysis;
//import Movie.java;

import java.io.*;
import java.util.*;



public class MovieStatistics { 
	
	
	/**\par
	 * protected helper class: Character <br>
	 * For storing name, count and gender of a character <br>
	 * character class uses predefined interface
	 */
	protected class Character implements Comparable<Character>{
		String name;
		int count;
		String gender;
		//default constructor
		public Character()
		{
			name="";
			count=0;
			gender="";
		}
		//constructor for the class
		public Character(String n, int c, String g){
			name = n;
			count = c;
			gender = g;
		}
		
		@Override 
		public int compareTo(Character arg0) {
			int compare=0;
			compare = (count > arg0.count) ? -1 : 0; 
		if(compare == 0)
		{ compare = (count ==arg0.count) ? 0 : 1; }
		return compare;} 
		}

	/**\par
	 * variable names: statsMovie <br>
	 * initial value:null<br>
	 * Instance of the class Movie
	 */
	protected Movie statsMovie;
	
	/**\par
	 * variable names: characters <br>
	 * Array of Character objects
	 */
	protected Character[] characters;
	
	private List<String> charNamesList;
	

	/**\par
	 * variable names: Male <br>
	 * Stores the male keywords
	 */
	private List<String> Male=Arrays.asList("he","his","him","man","father","brother","dude");
	
	/**\par
	 * variable names: Female <br>
	 * Stores the female keywords
	 */
	private List<String> Female=Arrays.asList("she","her","girl","lady","wife","mother","sister","daughter","mom");
	
	/**\par
	 * variable names: avoid <br>
	 * Stores the strings which should not be present in the names of the characters
	 */
	private String[] avoid = {"today", "yesterday", "tomorrow", "bridge", "road", "highway", "kitchen", "bathroom", "monday", "sunday", "tuesday", "wednesday", "thursday","friday", "saturday", "at", "on", "in", "under", "of", "later", "after", "before", "morning", "night", "afternoon", "evening", "life", "you", "end", "continued", "floor", "angle"};
	
	/**\par
	 * variable names: spChars <br>
	 * Stores the special characters which should not be present in the names of the characters
	 */
	private char[] spChars = {':', ';', '-', '_', '.', '!', '?', '(', ')', ','};
	
	/**\par
	 * variable names: totMaleWeight, totFemaleWeight <br>
	 * initial value: 0 <br>
	 * total number of occurrences of male and female keywords
	 */
	private double totMaleWeight=0,totFemaleWeight=0;
	
	/**\par
	 * constructor <br>
	 * initializes movie member, finds all characters in the movie script and stores them in the characters array with their counts and gender
	 */
	public MovieStatistics(Movie movie){
		statsMovie = movie;
		getCharList();
		Map<String, Integer> map = countEachChar();
		int count = map.size();
		characters = new Character[count];
		List<String> sortedList = sortMovieCharacters();
		int index = 0;
		for(String i : sortedList){
			characters[index] = new Character(i, map.get(i), "undetermined");
			index++;
		}
		determineCharGender();
	}
	
	/**\par
	 * method name: removeElt <br>
	 * remove a certain element from an ArrayList of Strings
	 */
	protected void removeElt(List<String> s, String elt){
		for (int i = 0; i < s.size(); i++) {
			if(s.get(i).equals(elt)){
				s.remove(i);
				break;
			}
		}
	}
	
	/**\par
	 * method name: checkUpper <br>
	 * checks if a String is all Uppercase
	 */
	protected boolean checkUpper(String s){
		for (int i = 0; i < s.length(); i++) {
			int ascii = (int) s.charAt(i);
			if (ascii > 96 && ascii < 123) return false;
		}
		return true;
	}
		
	/**\par
	 * method name: existsAsSubstring <br>
	 * checks if a string is a substring of elements in the given ArrayList of String
	 */
	protected boolean existsAsSubstring(List<String> myList, String word){
		for (String i : myList) if(i.contains(word)) return true;
		return false;
	}
	
	/**\par
	 * method name: checkName <br>
	 * check if a String is a valid name
	 */
	protected boolean checkName(String s){
		String[] splitName = s.split(" ");
		for (String i : splitName) {
			for (String j : avoid){
				if (i.trim().toLowerCase().equals(j.trim())) return false;
			}
		}
		for (int i = 0; i < s.length(); i++) {
			for (char c : spChars) if (c == s.charAt(i)) return false;
		}
		return true;
	}
	
	/**\par
	 * method name: findOccurrences <br>
	 * count the occurrences of a substring in other string
	 */
	protected int findOccurrences(String[] s, String[] sub){
		int l = s.length;
		int count = 0;
		for (int i = 0; i < sub.length-l+1; i++) {
			for (int cur = 0; cur < l; cur++) {
				if(! sub[i+cur].contains(s[cur])) break;
				if(cur == l-1) count++;
			}
		}
		return count;
	}
	
	/**\par
	 * method name: countScriptWords <br>
	 * Counts the number of unique words in the script
	 */
	private int countScriptWords(){
		List<String> tillNow = new ArrayList<String>();
		int count = 0;
		for(String[] i : statsMovie.words){
			for(String j : i){
				if (! tillNow.contains(j)){
					tillNow.add(j);
					count++;
				}
			}
		}
		return count;
	}

	/**\par
	 * method name: getCapitalNames <br>
	 * get all the names that are in uppercase
	 */
	private List<String> getCapitalNames(){
		List<String> chars = new ArrayList<String>();
		for (int i = 1; i < statsMovie.lines.size(); i++) {
			if(statsMovie.words.get(i).length < 4 && checkUpper(statsMovie.lines.get(i)) && checkName(statsMovie.lines.get(i)) && !(chars.contains(statsMovie.lines.get(i)))) chars.add(statsMovie.lines.get(i));
		}
		return chars;
	}

	/**\par
	 * method name: getPrefixes <br>
	 * returns the list of strings in the script that have a prifix "dr.", "mr." etc.
	 */
	private List<String> getPrefixes(){
		List<String> prefixes = new ArrayList<String>(){{add("dr.");add("mr."); add("mrs."); add("miss"); add("ms.");}};
		List<String> chars = getCapitalNames();
		for (int i = 0; i < chars.size(); i++) chars.set(i, chars.get(i).toLowerCase());
		for(String[] j : statsMovie.wordsLower){
			for (int i = 0; i < j.length-1; i++) {
				if(prefixes.contains(j[i]) && checkName(j[i+1]) && !(existsAsSubstring(chars, j[i+1]))) chars.add(j[i+1]); 
			}
		}
		return chars;
	}

	/**\par
	 * method name: getCharList <br>
	 * returns the list of names of all the characters in the script
	 */
	private List<String> getCharList(){
		charNamesList = getPrefixes();
		return charNamesList;
	}
	
	/**\par
	 * method name: countEachChar <br>
	 * returns the map storing the number of occurrences of each character
	 */
	private Map<String, Integer> countEachChar(){
		List<String> chars = charNamesList;
		Map<String, Integer> map = new HashMap<String, Integer>();
		for(String c : chars) map.put(c, 0);
		for(String c : chars){
			String[] charSplit = c.split(" ");
			for(String[] s : statsMovie.wordsLower){
				int temp = findOccurrences(charSplit, s);
				if(temp > 0){
					map.put(c, map.get(c)+temp);
				}
			}
		}
		List<String> tempChar = new ArrayList<String>(charNamesList);
		for(String i : tempChar){
			if(map.get(i) < 5){
				map.remove(i);
				charNamesList.remove(i);
			}
		}
		return map;
	}

	/**\par
	 * method name: countMovieCharacters <br>
	 * returns the number of characters in the script
	 */
	private int countMovieCharacters(){
		return characters.length;
	}
	
	/**\par
	 * method name: findMaleWeight <br>
	 * count the occurrences of male keywords in the given list of strings
	 */
	private double findMaleWeight(List<String> s)
	{
		double ansWeight=0;
		
			for(String j : s.get(0).split(" "))
			{
				if(Male.contains(j)){
					ansWeight+=1;
				}
				}

			for(String j : s.get(1).split(" "))
			{
				if(Male.contains(j)){
					ansWeight+=0.5;
				}
				}

			for(String j : s.get(2).split(" "))
			{
				if(Male.contains(j)){
					ansWeight+=0.25;
				}
				}
			return ansWeight;
	}
	
	/**\par
	 * method name: findFemaleWeight <br>
	 * count the occurrences of female keywords in the given list of strings
	 */
	private double findFemaleWeight(List<String> s)
	{
		double ansWeight=0;
		
			for(String j : s.get(0).split(" "))
			{
				if(Female.contains(j)){
					ansWeight+=1;
				}
				}

			for(String j : s.get(1).split(" "))
			{
				if(Female.contains(j)){
					ansWeight+=0.5;
				}
				}

			for(String j : s.get(2).split(" "))
			{
				if(Female.contains(j)){
					ansWeight+=0.25;
				}
				}
			return ansWeight;
	}
	
	/**\par
	 * method name: getTotMaleWeight <br>
	 * finds the value of the member totMaleWeight
	 */
	private double getTotMaleWeight()
	{
		String[] allWords=statsMovie.getMovieWords();
		double ansWeight=0;
		for(String i : allWords)
		{
			if(Male.contains(i))ansWeight+=1;
		}
		return ansWeight;
	}
	
	/**\par
	 * method name: getTotFemaleWeight <br>
	 * finds the value of the member totFemaleWeight
	 */
	private double getTotFemaleWeight()
	{
		String[] allWords=statsMovie.getMovieWords();
		double ansWeight=0;
		for(String i : allWords)
		{
			if(Female.contains(i))ansWeight+=1;
		}
		return ansWeight;
	}
	
	/**\par
	 * method name: findGender <br>
	 * finds the gender of the given character
	 */
	private String findGender(String name)
	{
		double maleWeight=0,femaleWeight=0;
		boolean done=true;
		String[] allWords=statsMovie.getMovieWords();
		for(int i=0;i< allWords.length;i++)
		{
			allWords[i]=allWords[i].toLowerCase();
		}
		List<String> lineWords=statsMovie.linesLower;
		for(int i=0;i<lineWords.size()-3;i++)
		{
				if(lineWords.get(i).contains(name))
				{
					maleWeight+=findMaleWeight(lineWords.subList(i, i+3));
					femaleWeight+=findFemaleWeight(lineWords.subList(i, i+3));
					}
			}
		for(int i=0;i<allWords.length;i++)
		{
			if(allWords[i].equals(name)){
				int j=i;
				while(j!=allWords.length-1){
					if(Male.contains(allWords[j])){maleWeight+=0.1;break;}
					else if(Female.contains(allWords[j])){femaleWeight+=0.1;break;}
				j++;
				}
			}
		}
		
		List<String> checkm=Arrays.asList("son","dad","father","boy","man","boyfriend","husband");
		List<String> checkf=Arrays.asList("daughter","girl","sister","sis","mom","wife","girlfriend", "woman", "women");
		for(String k : checkf)
		{if (name.contains(k)) 
			return "female";}
		for(String k : checkm)
		{if (name.contains(k)) 
			return "male";
		}
		
		if(maleWeight*totFemaleWeight>femaleWeight*totMaleWeight)return "male";
		else return "female";
	}
	
	/**\par
	 * method name: determineCharGender <br>
	 * finds gender of all the characters
	 */
	private void determineCharGender(){
		int index = 0;
		totMaleWeight=getTotMaleWeight();
		totFemaleWeight=getTotFemaleWeight();
		List<String> sortedList = sortMovieCharacters();
		for(String i : sortedList){
			List<String> checkm=Arrays.asList("son","dad","father","boy","man","boyfriend","husband");
			List<String> checkf=Arrays.asList("daughter","girl","sister","sis","mom","wife","girlfriend", "woman", "women");
			for(String k : checkm)
			{if (i.contains(k)) 
				{characters[index] .gender="male";break;}
			}
			for(String k : checkf)
			{if (i.contains(k)) 
				{characters[index] .gender="female";break;}
			}
			if(characters[index].count>15)
			characters[index] .gender=findGender(i);
			index++;
		}
	} 

	/**\par
	 * method name: printCharCounts <br>
	 * prints the character names and their counts in order sorted according to their first name
	 */
	public void printCharCounts(){
		int spaces = 30;
		System.out.println("\nCHARACTER NAME           COUNT");
		System.out.println("==============================");
		for(Character c : characters){
			int temp = spaces-c.name.length()-Integer.toString(c.count).length();
			System.out.print(c.name.toUpperCase());
			for (int i = 0; i < temp; i++) {
				System.out.print(".");
			}
			System.out.println(c.count);
		}
	}

	/**\par
	 * method name: printCharCountsWithGende <br>
	 * prints the character names and their counts and gender in order sorted according to their first name
	 */
	public void printCharCountsWithGender(){
		int spaces = 40;
		System.out.println("\nCHARACTER NAME (GENDER)            COUNT");
		System.out.println("========================================");
		for(Character c : characters){
			int temp = spaces-c.name.length()-Integer.toString(c.count).length();
			if(c.gender.equals("male")) temp -= 7;
			else if(c.gender.equals("undetermined")) temp -= 15;
			else temp -= 9;
			  
			System.out.print(c.name.toUpperCase()+" ("+c.gender.toUpperCase()+")");
			for (int i = 0; i < temp; i++) {
				System.out.print(".");
			}
			System.out.println(c.count);
		}
	}
	
	/**\par
	 * method name: sortMovieCharacters <br>
	 * sorts the names of the movie characters in the alphabetical order
	 */
	private List<String> sortMovieCharacters(){
		java.util.Collections.sort(charNamesList);
		return charNamesList;
	}

	
		
}
