package cs296MovieAnalysis;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
///
///This Class is used for finding the genre of the concerned movie
///
public class FindGenre {
	/**\par
	 * variable names:actCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int actCount=0;
	/**\par
	 * variable names:comCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int comCount=0;
	/**\par
	 * variable names:draCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int draCount=0;
	/**\par
	 * variable names:romCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int romCount=0;
	/**\par
	 * variable names:sciCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int sciCount=0;
	/**\par
	 * variable names:horCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int horCount=0;
	/**\par
	 * variable names:fanCount <br>
	 * initial value:0<br>
	 * These members keep a count of occurence of action keywords
	 */
	private int fanCount=0;
	///List name:act <br> The list stores all the keywords corresponding to the action genre
	private List<String> act = Arrays.asList("crime", "spy", "kill", "pilot", "hurt", "end",
			"fast", "run", "crew", "shoot", "kick", "weapon", "tank", "fir", "bullet",
			"explo", "toss",  "train", "karate", "kung-fu");
	///List name:com <br> The list stores all the keywords corresponding to the comedy genre
	private List<String> com = Arrays.asList("cool", "married", "sex", "fun", "beer", "crash",
			"dude", "idiot", "shit", "parody", "happy", "happi", "smile", "confused",
			"shout", "honey", "giggle", "laugh", "dance", "joy", "ha ha");
	///List name:dra <br> The list stores all the keywords corresponding to the drama genre
	private List<String> dra= Arrays.asList("daddy", "colonel", "husband", "state", "sick", 
			"sense", "pool" ,"returns", "emotion", "cry", "cri", "hope", "judge", "jury", 
			"king", "queen");
	///List name:rom <br> The list stores all the keywords corresponding to the romance genre
	private List<String> rom= Arrays.asList("love", "cuddle", "married", "sailor", "crash", 
			"shepherd", "wills", "daughter", "letter", "surprised", "restaurant",
			"wedding", "met", "funny", "fun");
	///List name:sci <br> The list stores all the keywords corresponding to the scifi genre
	private List<String> sci= Arrays.asList("alien", "planet", "galaxy" , "universe ", "monitor",
			"crew", "robot", "duke", "console", "pilot", "spider", "level", "system",
			"tank", "panel", "weapon", "skin", "hunter", "brain", "astro", "comput", "law", 
			"nano", "space", "star");
	///List name:hor <br> The list stores all the keywords corresponding to the horror genre
	private List<String> hor= Arrays.asList("cabin", "skin", "bones", "vampire", "teeth", "jeep", "woods",
			"hunter", "scared", "bloody", "death", "psycopath", "evil", "murder",
			"zombie", "monster", "devil", "demon", "ghost");
	///List name : fan <br> The list stores all the keywords corresponding to the fantasy genre
	private List<String> fan= Arrays.asList("lord", "dragon", "unicorn", "wizard", "witch", 
			"knight", "furious", "doom", "queen", "final", "cat", "curse", "dragons",
			"merry", "wizard", "prince", "hobbit", "elves", "dragon", "monster");
	private Movie genreMovie;//!<declaration of the movie whose genre we want to find 
	/**
	 * This is the constructor of the class which initialises<br>
	 * the member movie
	 */
	public FindGenre(Movie movie){
		genreMovie = movie;
	}
	/*!\par
	 * method name: findGenre <br>
	 * The method finds the genre of the movie<br>
	 * and returns the genres found applicable <br>
	 * in the form of an array of strings<br>
	 */
	public String[] findGenre(){
		String[] genreWords= genreMovie.getMovieWords();
		for(int i = 0; i < genreWords.length; i++) genreWords[i] = genreWords[i].toLowerCase();
		
		for(int i=0;i<genreWords.length;i++)
		{
			if(act.contains(genreWords[i]))
					actCount+=1;
			if(com.contains(genreWords[i]))
					comCount+=1;
			if(dra.contains(genreWords[i]))
					draCount+=1;
			if(rom.contains(genreWords[i]))
					romCount+=1;
			if(sci.contains(genreWords[i]))
					sciCount+=1;
			if(hor.contains(genreWords[i]))
					horCount+=1;
			if(fan.contains(genreWords[i]))
					fanCount+=1;
		}
		
		double total=actCount+comCount+draCount+romCount+horCount+fanCount+sciCount;

		
		List<String> temp=new ArrayList<String>(); 
		if (actCount/total > 0.15 || actCount>=100)		
			{temp.add("Action");}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
		if (comCount/total> 0.15 || comCount>=100)		
			temp.add("Comedy");

		if (draCount/total > 0.15 || draCount>=120)		
			temp.add("Drama");

		if (romCount/total > 0.15 || romCount>=120)		
			temp.add("Romance");

		if (horCount/total > 0.25 || horCount>=100)		
			temp.add("Horror");

		if (fanCount/total > 0.15 || fanCount>=100)		
			temp.add("Fantasy");

		if (sciCount/total > 0.15)		
			temp.add("Sci-Fi");
		String[] temp1 = new String[temp.size()];
		return temp.toArray(temp1);
	}
	/**
	 * \par
	 * method name: printGenre <br>
	 * Prints the genres of the movie found by using the findGenre function
	 */
	public void printGenre(){
		System.out.println("\nTHE MOVIE BELONGS TO FOLLOWING GENRES: ");
		String[] genres = findGenre();
		for(int i = 0; i < genres.length; i++){
			System.out.println((i+1)+". "+genres[i]);
		}
	}
}
