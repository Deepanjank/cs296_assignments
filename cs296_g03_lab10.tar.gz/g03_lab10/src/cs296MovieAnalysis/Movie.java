package cs296MovieAnalysis;
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;
import java.util.*;



public class Movie {
		/**\par
		 * variable names:movieFilename <br>
		 * initial value:null<br>
		 * Stores the name of the file to be read
		 */
		public String movieFilename;
		/**\par
		 * variable names:author <br>
		 * initial value:null<br>
		 * Stores the name of the author of the script
		 */
		private String author;
		/**\par
		 * variable names:title <br>
		 * initial value:null<br>
		 * Stores the title of the movie
		 */
		private String title;
		/**\par
		 * variable names:words <br>
		 * Stores the words in the script as a 2D array
		 */
		public List<String[]> words = new ArrayList<String[]>();
		/**\par
		 * variable names:lines <br>
		 * Stores the lines in the script as an ArrayList of strings
		 */
		public List<String> lines = new ArrayList<String>();
		/**\par
		 * variable names:wordsLower <br>
		 * Stores the words in the script in lowercase as a 2D array
		 */
		public List<String[]> wordsLower = new ArrayList<String[]>();
		/**\par
		 * variable names:linesLower <br>
		 * Store the lines in the script in lowercase as an ArrayList of Strings
		 */
		public List<String> linesLower = new ArrayList<String>();

		/**\par
		 * Constructor <br>
		 * Stores name of the movie in movieFilename and reads the file into the members via method readWords
		 */
		public Movie(String arg){
				movieFilename = arg;
				try {
						readWords();
				}
				catch (FileNotFoundException e) {
						System.out.println("Error " + e.getMessage());
						e.printStackTrace();
				}
;
		}

		/**\par
		 * method name: readWords <br>
		 * Reads the file and stores lines in lines
		 * and stores words in words
		 * stores corresponding lowercase transformations in wordsLower and linesLower
		 */
		private void readWords() throws FileNotFoundException {
				BufferedReader br = new BufferedReader(new FileReader(movieFilename));
				String line = null;
				try {
						while ((line = br.readLine()) != null){
								line = line.trim();
								if (line.length() > 0){
										lines.add(line);
										words.add(line.split(" "));
										String lineLower = line.toLowerCase();
										linesLower.add(lineLower);
										wordsLower.add(lineLower.split(" "));
								}
								
								
						}
						
						br.close();
				}
				catch (IOException e) {
						System.out.println("Error " + e.getMessage());
						e.printStackTrace();
				}
		}
		
		

		/**\par
		 * method name: getMovieTitle <br>
		 * Returns the title of the movie
		 */
		private String getMovieTitle(){
			title=lines.get(0);
				return lines.get(0);
		}

		/**\par
		 * method name: getMovieAuthor <br>
		 * Returns the name of the author of the script
		 */
		private String getMovieAuthor(){
			author=lines.get(2);
			if (linesLower.get(1).equals("written by") || linesLower.get(1).equals("by"))
				return lines.get(2);
				else if (linesLower.get(1).contains("written by") || linesLower.get(1).contains("by"))
				return (lines.get(1).substring(lines.get(1).indexOf("by") + 2)).trim();
				else return lines.get(1);
		}

		/**\par
		 * method name: printMovieTitle <br>
		 * Prints the title of the movie
		 */
		public void printMovieTitle(){
				System.out.println("The Title of the movie is : "+getMovieTitle());
		}

		/**\par
		 * method name: printMovieAuthor <br>
		 * Prints the name of the author of the script
		 */
		public void printMovieAuthor(){
				System.out.println("The author of the script is : "+getMovieAuthor());
		}
		
		/**\par
		 * method name: getMovieWords <br>
		 * Returns the array of all the words (not only unique) in the script
		 */
		public String[] getMovieWords(){
				List<String> allWords = new ArrayList<String>();
				for (String[] i : words){
						for (String j : i) allWords.add(j);
				}
				String[] ans = new String[allWords.size()];
			return allWords.toArray(ans);
		}

		
}
