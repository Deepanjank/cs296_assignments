import java.util.List;

import cs296MovieAnalysis.FindActors;
import cs296MovieAnalysis.FindGenre;
import cs296MovieAnalysis.Movie;
import cs296MovieAnalysis.MovieStatistics;


public class MovieAnalysisG03 {
	public static void main(String[] args) {
		System.out.println("\n\nBELOW IS THE MOVIE ANALYSIS : \n");
		
		
		Movie movie = new Movie(args[0]);
		movie.printMovieTitle();
		movie.printMovieAuthor();
		
		MovieStatistics stats = new MovieStatistics(movie);
		stats.printCharCountsWithGender();
		
		FindActors actors = new FindActors(movie);
		actors.printActors();
	
		FindGenre genre=new FindGenre(movie);
		genre.printGenre();

		System.out.println("");
		
}
}
//discuss private public and how and from where to call
