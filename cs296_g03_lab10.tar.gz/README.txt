group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

INSTRUCTION:

After compilation run
java -cp ./obj MovieAnalysisG03 pathtoinputfile
	OR
java -jar ./bin/MyMovie.jar pathtotheinputfile

OOPs ideas Used :

Created MovieAnalysisG03 class. Created cs296MovieAnalysis package which contains all the other classes.
Some of the classes in the package import the other classes to create their instances and use their members and methods.
The classes contain all public, private and protected members and methods.

i)Interfaces
Defined a Character class which implemented the  pre-defined compared interface.
Overid the compareTo function of comparable interface to compare objects of Character
class for sorting.

ii)Inheritance
Inherited class FindActors from MovieStatistics.
So most of the members and methods in the class MovieStatistics are protected.

Sources:
Thinking in Java: http://www.mindviewinc.com/Books/TIJ/
Stack Overflow :    www.stackoverflow.com
Java SE 6 Documentation : http://docs.oracle.com/javase/6/docs/api/
Java Tutorials : http://docs.oracle.com/javase/tutorial/
