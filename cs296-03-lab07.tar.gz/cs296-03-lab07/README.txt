Lab 07
group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

Sources:
(1) Short Perf Tutorial                       : http://www.baptiste-wicht.com/2011/07/profile-applications-linux-perf-tools/
(2) The Perf Wiki                             : https://perf.wiki.kernel.org/index.php/Main_Page
(3) GProf Tutorial                            : http://www.thegeekstuff.com/2012/08/gprof-tutorial/index.html
(4) Profiling on Linux                        : http://www.pixelbeat.org/programming/profiling/
(5) TeX - LaTeX Stack Exchange                : http://tex.stackexchange.com/
