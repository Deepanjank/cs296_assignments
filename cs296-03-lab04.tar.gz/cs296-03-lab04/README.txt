Lab 04
group number: 3

group members:
Anurag Shirolkar  120050003
Deepanjan Kundu   120050009
Syamantak Naskar  120050016

All work that we are submitting is our own work and we have not plagiarized it from anywhere.

Sources:
(1) Ten minute guide to diff and patch           : http://jungels.net/articles/diff-patch-ten-minutes.html
(2) Subversion (SVN) cheat sheet                			 	 : http://www.abbeyworkshop.com/howto/misc/svn01/
(3) Subversion tutorial							 : http://www.clear.rice.edu/comp314/svn.html
(4) Subversion book    						 : http://svnbook.red-bean.com/en/1.7/index.html
(5) Git-SVN crash course								 : http://git.or.cz/course/svn.html
(6) pro GIT book								 : http://git-scm.com/book
(7) Git a simple guide								 : http://rogerdudler.github.com/git-guide/
